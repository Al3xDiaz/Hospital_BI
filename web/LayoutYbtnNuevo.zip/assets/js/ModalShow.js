$('#btnEditar').on('click', function(ev) {
$('#ModalEditar').modal({
  show: 'true'
});
});

  $('#btnEliminar').on('click', function(ev) {
$('#ModalEliminar').modal({
  show: 'true'
});
});

$('#btnNuevo').on('click', function(ev) {
$('#modalAgregar').modal({
show: 'true'
});
});
