$('#btnEditar').on('click', function(ev) {
$('#ModalEditar').modal({
  show: 'true'
});
});

  $('#btnEliminar').on('click', function(ev) {
$('#ModalEliminar').modal({
  show: 'true'
});
});
